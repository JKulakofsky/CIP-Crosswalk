from sys import argv
import re
import unicodecsv

script, filename = argv

csvfile = "tmp2.csv"

txt = open(filename)
red = txt.read()
reed = re.sub('["]', '', red)
reid = re.sub("[']", '', reed)
with open(csvfile, "w") as output:
	output.write(reid)

