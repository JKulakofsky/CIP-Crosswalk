import requests
import re
import unicodecsv
from cStringIO import StringIO
import time

r = requests.get('http://nces.ed.gov/ipeds/cipcode/browse.aspx?y=55')
data = r.text

CIP_full = []

for i in range (0, 1720):
	cipgex = '<li><a href="cipdetail.aspx\?y=55&amp;cipid=.+?" title="View this CIP">(.+?).</a></li>'
	cipcompiled = re.compile(cipgex)
	cip = re.findall(cipcompiled,data)
	CIP_full.append(cip[i])

print u', '.join(CIP_full)
