from sys import argv
import re

script, filename = argv

txt = open(filename)
red = txt.read()

reed = re.sub(r'(?<=\|)\s+(.*?)(?=\|)','\\1',red)

csvfile = "tmp3.csv"
with open(csvfile,"w") as output:
	output.write(reed)
