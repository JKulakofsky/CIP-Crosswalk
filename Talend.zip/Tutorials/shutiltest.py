import shutil
import os

# os.chdir('../States_and_Abbreviations')
shutil.move('test.txt', 'superlongfilename.txt')
