import requests 
import re

html = requests.get("http://finance.yahoo.com/q?s=aapl&q1=1")

htmltext = html.text

regex = '<span id="yfs_l84_aapl">(.+?)</span>'

pattern = re.compile(regex)

price = re.findall(pattern,htmltext)

print price[0]
