from mechanize import Browser
import re

br = Browser()
br.set_handle_robots(False)
br.addheaders = [('User-agent','Firefox')]
br.open("http://google.com")

for f in br.forms():
    print f

br.select_form('f')
br.form['q'] = 'foo'
br.submit()

resp = None

for link in br.links():
    siteMatch = re.compile('www.foofighters.com').search(link.url)
    
    if siteMatch:
        resp = br.follow_link(link)
        break

content = resp.get_data()
print content
