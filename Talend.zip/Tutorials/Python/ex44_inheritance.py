# defines the base class "Parent," it's a base class because it is-a object
class Parent(object):

# writes three functions that only take the self parameter and print out a line
	def override(self):
		print "PARENT override()"
	
	def implicit(self):
		print "PARENT implicit()"
	
	def altered(self):
		print "PARENT altered()"

# defines the child class that is-a Parent
class Child(Parent):
	
# defines the override function for the Child class which just prints a line
	def override(self):
		print "CHILD override()"
	
# defines the altered function for the Child which prints a line then calls on
# the altered function in the super of child (the class nested above it) which
# is the Parent then prints a last line
	def altered(self):
		print "CHILD, BEFORE PARENT altered()"
		super(Child, self).altered()
		print "CHILD, AFTER PARENT altered()"

# sets dad and son to instances of the classes
dad = Parent()
son = Child()

# calls the implicit function from dad and son.  since there is no implicit function
# in Child it gets the fuction from Parent
dad.implicit()
son.implicit()

# calls the override function from Parent and Child
dad.override()
son.override()

# calls the altered function from Parent and Child
dad.altered()
son.altered()
