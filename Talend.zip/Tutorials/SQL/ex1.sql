CREATE TABLE person (
	id INTEGER PRIMARY KEY,
	first_name TEXT,
	middle_initial TEXT,
	last_name TEXT,
	age INTEGER,
	height INTEGER
	
);
