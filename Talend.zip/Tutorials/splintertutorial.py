from splinter import Browser

browser = Browser()
browser.visit('http://google.com')
browser.fill('q', 'World Cup 2014')
button = browser.find_by_name('btnG')
button.click()

if browser.is_text_present('New York Times'):
    print "Yes, found it! :)"
else:
    print "No, didn't find it :("

browser.quit()
